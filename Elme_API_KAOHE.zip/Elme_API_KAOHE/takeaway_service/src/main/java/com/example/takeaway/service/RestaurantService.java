package com.example.takeaway.service;

import com.example.takeaway.entity.Restaurant;
import com.baomidou.mybatisplus.extension.service.IService;

public interface RestaurantService extends IService<Restaurant> {

}
