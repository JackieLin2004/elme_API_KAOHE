package com.example.takeaway.service.impl;

import com.example.takeaway.entity.Menu;
import com.example.takeaway.mapper.MenuMapper;
import com.example.takeaway.service.MenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class MenuServiceImpl extends ServiceImpl<MenuMapper, Menu> implements MenuService {

}
