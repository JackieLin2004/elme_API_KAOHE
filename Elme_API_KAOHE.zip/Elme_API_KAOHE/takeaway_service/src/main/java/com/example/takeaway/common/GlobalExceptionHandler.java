package com.example.takeaway.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLIntegrityConstraintViolationException;

/**
 * 全局异常处理
 */
//这里是指定拦截带了RestController注解的类（也就是这些controller），以及Controller注解
@ControllerAdvice(annotations = {RestController.class})
@ResponseBody
//输出日志
@Slf4j
public class GlobalExceptionHandler {
    /**
     * 异常处理方法
     * @return
     */
    //ExceptionHandler是指定要处理的异常
    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    //参数注入异常信息
    public R<String> exceptionHandler(SQLIntegrityConstraintViolationException ex){
        //打印异常信息
        log.error(ex.getMessage());
        //Duplicate entry '1234567' for key 'employee.idx_username'
        //判断如果包含Duplicate entry（重复条目）说明就是用户名重复就返回指定用户名
        if (ex.getMessage().contains("Duplicate entry")){
            //指定分割用户名
            String[] split = ex.getMessage().split(" ");
            String msg = split[2] + "已存在";
            return R.error(msg);
        }

//        return R.error("失败了");
        //如果不含上面if的内容
        return R.error("未知错误");
    }

    /**
     * 异常处理方法
     * @return
     */
    //ExceptionHandler是指定要处理的异常
    @ExceptionHandler(CustomException.class)
    //参数注入异常信息
    public R<String> exceptionHandler(CustomException ex){
        //打印异常信息
        log.error(ex.getMessage());
        //获取到异常信息，返回给页面
        return R.error(ex.getMessage());
    }
}
