package com.example.takeaway.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.takeaway.common.R;
import com.example.takeaway.entity.User;
import com.example.takeaway.entity.vo.LoginVo;
import com.example.takeaway.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

@Api(description="登录注册")
@RestController
@RequestMapping("/takeaway/user")
public class UserController {

    @Autowired
    private UserService userService;

    //登录
    @PostMapping("login")
    @ApiOperation(value = "登录")
    public R logonUser(@ApiParam(name = "loginVo", value = "账号和密码", required = true)
                       @RequestBody LoginVo login){
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername,login.getUsername());
        queryWrapper.eq(User::getPassword,login.getPassword());
        //调用service方法实现登录
        User user = userService.getOne(queryWrapper);
        if(ObjectUtils.isEmpty(user)){
            return R.error("登录失败");
        }
        //登录
        return R.success(user);
    }

    //注册
    @PostMapping("register")
    @ApiOperation(value = "注册")
    public R registerUser(@ApiParam(name = "user", value = "账号和密码以及其他信息", required = true)
                          @RequestBody User user){
        boolean save = userService.save(user);
        return R.success("注册成功");
    }
}
