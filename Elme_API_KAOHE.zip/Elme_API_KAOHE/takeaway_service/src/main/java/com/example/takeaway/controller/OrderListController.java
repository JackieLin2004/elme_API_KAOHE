package com.example.takeaway.controller;


import cn.hutool.db.sql.Order;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.takeaway.common.R;
import com.example.takeaway.entity.Menu;
import com.example.takeaway.entity.MenuItem;
import com.example.takeaway.entity.OrderDetail;
import com.example.takeaway.entity.OrderList;
import com.example.takeaway.entity.vo.MenuVo;
import com.example.takeaway.entity.vo.OrderVo;
import com.example.takeaway.service.OrderDetailService;
import com.example.takeaway.service.OrderListService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(description="订单")
@RestController
@RequestMapping("/orders")
public class OrderListController {

    @Autowired
    private OrderListService orderListService;

    @Autowired
    private OrderDetailService orderDetailService;

    @PostMapping("/create")
    @ApiOperation(value = "下单")
    public R createOrder(@ApiParam(name = "orderVo", value = "订单信息", required = true)
                             @RequestBody OrderVo orderVo) {
        // 在此处理创建订单的逻辑，包括插入订单和订单详情信息到数据库
        OrderList orderList = new OrderList();
        orderList.setOrderStatus("pey");
        orderList.setRestaurantId(orderVo.getRestaurantId());
        orderList.setTotalAmount(orderVo.getTotalAmount());
        orderList.setUserId(orderVo.getUserId());
        orderList.setRestaurantName(orderVo.getRestaurantName());
        orderList.setTotalAmount(orderVo.getTotalAmount());
        //保存订单信息
        orderListService.save(orderList);

        // 返回成功或失败的响应
        List<MenuVo> menuVoList = orderVo.getMenuVoList();
        for (MenuVo menuVo : menuVoList) {
            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setMenuItemId(menuVo.getMenuItemId());
            orderDetail.setMenuItemName(menuVo.getMenuItemName());
            orderDetail.setOrderId(orderList.getOrderId());
            orderDetail.setQuantity(menuVo.getQuantity());
            orderDetail.setSubtotalAmount(menuVo.getSubtotalAmount());
            //保存订单详情，菜品价格
            orderDetailService.save(orderDetail);
        }
        return R.success("下单成功");
    }

    @GetMapping("/{Userid}")
    @ApiOperation(value = "根据用户id获取订单列表")
    public R getOrderById(@ApiParam(name = "userId", value = "用户id", required = true)
                              @PathVariable Integer Userid) {
        // 在此根据用户id查询订单列表
        LambdaQueryWrapper<OrderList> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(OrderList::getUserId,Userid);
        List<OrderList> list = orderListService.list(queryWrapper);
        return R.success(list);
    }

    @GetMapping("/{orderId}/details")
    @ApiOperation(value = "根据订单id获取菜品列表")
    public R getOrderDetailsByOrderId(@ApiParam(name = "orderId", value = "订单id", required = true)
                                          @PathVariable Integer orderId) {
        // 在此根据订单ID查询订单详情信息
        LambdaQueryWrapper<OrderDetail> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(OrderDetail::getOrderId , orderId);
        // 返回订单详情列表
        List<OrderDetail> list = orderDetailService.list(queryWrapper);
        return R.success(list);
    }

    // 其他订单相关的操作可以在这里添加
}

