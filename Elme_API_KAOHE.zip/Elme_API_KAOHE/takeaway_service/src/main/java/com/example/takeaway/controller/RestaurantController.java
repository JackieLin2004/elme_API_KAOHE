package com.example.takeaway.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.takeaway.common.R;
import com.example.takeaway.entity.Menu;
import com.example.takeaway.entity.Restaurant;
import com.example.takeaway.service.MenuService;
import com.example.takeaway.service.RestaurantService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(description="餐厅")
@RestController
@RequestMapping("/takeaway/restaurant")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    //根据餐馆获取菜单
    @GetMapping("getRestaurants")
    @ApiOperation(value = "获取餐馆列表")
    public R getMenuByRestaurant(){
        List<Restaurant> list = restaurantService.list();
        return R.success(list);
    }
}
