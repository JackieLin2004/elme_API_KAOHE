package com.example.takeaway.entity.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class MenuVo {

    //菜品id
    private Integer menuItemId;

    //菜品名称
    private String menuItemName;

    //菜品数量
    private Integer quantity;

    //一个菜品价格
    private BigDecimal subtotalAmount;
}
