package com.example.takeaway.common;

/**
 * 自定义业务异常类
 */
public class CustomException extends RuntimeException {
    public CustomException(String message){
        //调用RuntimeException的构造方法传入参数
        super(message);
    }
}
