package com.example.takeaway.service.impl;

import com.example.takeaway.entity.OrderList;
import com.example.takeaway.mapper.OrderListMapper;
import com.example.takeaway.service.OrderListService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class OrderListServiceImpl extends ServiceImpl<OrderListMapper, OrderList> implements OrderListService {

}
