package com.example.takeaway.service;

import com.example.takeaway.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

public interface UserService extends IService<User> {

}
