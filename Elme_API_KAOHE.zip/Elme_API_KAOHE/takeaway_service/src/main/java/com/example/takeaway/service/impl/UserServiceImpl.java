package com.example.takeaway.service.impl;

import com.example.takeaway.entity.User;
import com.example.takeaway.mapper.UserMapper;
import com.example.takeaway.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

}
