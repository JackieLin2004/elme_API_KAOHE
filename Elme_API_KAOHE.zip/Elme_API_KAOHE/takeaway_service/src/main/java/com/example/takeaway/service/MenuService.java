package com.example.takeaway.service;

import com.example.takeaway.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

public interface MenuService extends IService<Menu> {

}
