package com.example.takeaway.service;

import com.example.takeaway.entity.OrderDetail;
import com.baomidou.mybatisplus.extension.service.IService;

public interface OrderDetailService extends IService<OrderDetail> {

}
