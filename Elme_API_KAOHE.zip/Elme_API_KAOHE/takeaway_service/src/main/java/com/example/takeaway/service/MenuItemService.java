package com.example.takeaway.service;

import com.example.takeaway.entity.MenuItem;
import com.baomidou.mybatisplus.extension.service.IService;

public interface MenuItemService extends IService<MenuItem> {

}
