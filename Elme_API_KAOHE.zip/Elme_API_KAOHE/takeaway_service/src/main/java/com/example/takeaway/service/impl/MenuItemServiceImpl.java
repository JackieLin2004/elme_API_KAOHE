package com.example.takeaway.service.impl;

import com.example.takeaway.entity.MenuItem;
import com.example.takeaway.mapper.MenuItemMapper;
import com.example.takeaway.service.MenuItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class MenuItemServiceImpl extends ServiceImpl<MenuItemMapper, MenuItem> implements MenuItemService {

}
