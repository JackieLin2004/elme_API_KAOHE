package com.example.takeaway.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.takeaway.common.R;
import com.example.takeaway.entity.Menu;
import com.example.takeaway.entity.MenuItem;
import com.example.takeaway.service.MenuItemService;
import com.example.takeaway.service.MenuService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(description="菜品")
@RestController
@RequestMapping("/takeaway/menu-item")
public class MenuItemController {

    @Autowired
    private MenuItemService menuItemService;

    //根据餐馆获取菜品
    @GetMapping("getMenuByRestaurant/{menuId}")
    @ApiOperation(value = "根据菜单获取菜品")
    public R getMenuItemByMenu(@ApiParam(name = "menuId", value = "菜品id", required = true)
                                   @PathVariable Integer menuId){
        LambdaQueryWrapper<MenuItem> queryWrapper = new LambdaQueryWrapper<>();
        LambdaQueryWrapper<MenuItem> itemLambdaQueryWrapper = queryWrapper.eq(MenuItem::getMenuId, menuId);
        List<MenuItem> list = menuItemService.list(itemLambdaQueryWrapper);
        return R.success(list);
    }
}
