package com.example.takeaway.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.takeaway.common.R;
import com.example.takeaway.entity.Menu;
import com.example.takeaway.entity.User;
import com.example.takeaway.service.MenuService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import java.util.List;


@Api(description="菜单")
@RestController
@RequestMapping("/takeaway/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;

    //根据餐馆获取菜单
    @GetMapping("getMenuByRestaurant/{restaurantId}")
    @ApiOperation(value = "根据餐馆获取菜单")
    public R getMenuByRestaurant(@ApiParam(name = "restaurantId", value = "餐馆id", required = true)
                        @PathVariable Integer restaurantId){
        LambdaQueryWrapper<Menu> queryWrapper = new LambdaQueryWrapper<>();
        LambdaQueryWrapper<Menu> menuLambdaQueryWrapper = queryWrapper.eq(Menu::getRestaurantId, restaurantId);
        List<Menu> list = menuService.list(menuLambdaQueryWrapper);
        return R.success(list);
    }
}
