package com.example.takeaway.service;

import com.example.takeaway.entity.OrderList;
import com.baomidou.mybatisplus.extension.service.IService;

public interface OrderListService extends IService<OrderList> {

}
