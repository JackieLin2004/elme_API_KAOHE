package com.example.takeaway.entity.vo;

import lombok.Data;

@Data
public class LoginVo {

    private String username;

    private String password;
}
