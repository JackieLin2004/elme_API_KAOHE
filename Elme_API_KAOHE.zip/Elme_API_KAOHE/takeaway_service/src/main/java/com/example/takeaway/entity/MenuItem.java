package com.example.takeaway.entity;

import java.math.BigDecimal;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class MenuItem implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "menu_item_id", type = IdType.AUTO)
    private Integer menuItemId;

    private Integer menuId;

    private String name;

    private String description;

    private BigDecimal price;


}
