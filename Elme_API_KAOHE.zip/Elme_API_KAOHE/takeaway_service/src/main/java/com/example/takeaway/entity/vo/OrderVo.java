package com.example.takeaway.entity.vo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderVo {

    //用户id
    private Integer userId;

    //餐厅id
    private Integer restaurantId;

    //餐厅名称
    private String restaurantName;

    //总价
    private BigDecimal totalAmount;

    //菜品列表
    private List<MenuVo> menuVoList;
}
