package com.example.takeaway.service.impl;

import com.example.takeaway.entity.Restaurant;
import com.example.takeaway.mapper.RestaurantMapper;
import com.example.takeaway.service.RestaurantService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class RestaurantServiceImpl extends ServiceImpl<RestaurantMapper, Restaurant> implements RestaurantService {

}
